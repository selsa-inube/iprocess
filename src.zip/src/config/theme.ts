import { themes } from "@mocks/design/themes";


const theme = {
  ...themes['basic'],
};

export { theme };
