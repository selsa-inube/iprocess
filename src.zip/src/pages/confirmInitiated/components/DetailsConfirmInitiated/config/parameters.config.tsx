const titlesParameters = [
    {
      id: "parameter",
      titleName: "Parámetro",
      priority: 0,
    },
    {
      id: "value",
      titleName: "Valor",
      priority: 0,
    },
  ];

  const breakPointsParameters = [
    { breakpoint: "(min-width: 1091px)", totalColumns: 2 },
  ];

  export { titlesParameters, breakPointsParameters };
  