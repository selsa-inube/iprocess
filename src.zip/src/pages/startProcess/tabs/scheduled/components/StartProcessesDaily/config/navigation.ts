const crumbsStartProcessesDaily =  [
  {
    id: "startProcess",
    path: "/",
    label: "Iniciar procesos",
    isActive: false,
  },
  {
    id: "diaries",
    path: "/startProcessesDaily",
    label: "Diarios",
    isActive: true,
  },

];

export { crumbsStartProcessesDaily };