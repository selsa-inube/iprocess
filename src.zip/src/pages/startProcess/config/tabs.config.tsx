const startProcessTabsConfig = {
  scheduled: {
    id: "scheduled",
    isDisabled: false,
    label: "Programados",
  },
  onDemand: {
    id: "on-demand",
    isDisabled: false,
    label: "Por demanda",
  },
};

export { startProcessTabsConfig };
