import { spacing } from "./spacing/spacing";

const tokens = {
  spacing,
};

export { tokens };