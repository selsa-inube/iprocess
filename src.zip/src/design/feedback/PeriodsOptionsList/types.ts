interface IOption {
    id: string;
    label: string;
  }

  export type { IOption };