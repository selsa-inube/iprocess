interface IApprovalEntry{
  observation: string;
}
export type { IApprovalEntry };
