interface IApprovalEntry{
  approval: boolean;
  observation: string;
}
export type { IApprovalEntry };
