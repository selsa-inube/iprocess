import styled from "styled-components";

const StyledContainerInput = styled.div`
display: flex;
  & > div {
    width: 100%;
  }
`;

export { StyledContainerInput };
