interface ILabel {
    id: string;
    titleName: string;
  }

  export type {ILabel}