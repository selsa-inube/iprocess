interface IDecisionEntry {
    justification: string;
}

export type { IDecisionEntry };