import { basic } from "./basic";

const themes = {
 basic,

};

export { themes };
