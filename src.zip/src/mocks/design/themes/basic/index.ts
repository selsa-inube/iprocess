import { businessUnitTheme } from "./basic";

const basic = {
    ...businessUnitTheme

};

export { basic };