const periodsData = [
    {
      id: "06",
      label: "Junio 2024",
    },
    {
      id: "07",
      label: "Julio 2024",
    },
    { 
      id: "08",
      label: "Agosto 2024",
    },
    {
      id: "09",
      label: "Septiembre 2024",
    },
    {
      id: "10",
      label: "Octubre 2024",
    },
    
  ];
  
  export { periodsData };