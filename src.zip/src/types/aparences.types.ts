enum ComponentAppearance {
    DANGER = 'danger',
    DARK = 'dark',
    GRAY = 'gray',
    HELP = 'help',
    LIGHT = 'light',
    PRIMARY = 'primary',
    SUCCESS = 'success',
    WARNING = 'warning',
}

export { ComponentAppearance };