interface IServerDomain {
  id: string;
  label: string;
  disabled?: boolean;
}

export type { IServerDomain };


